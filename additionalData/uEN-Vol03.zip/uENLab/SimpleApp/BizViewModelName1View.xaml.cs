﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using uEN.UI;


namespace SimpleApp
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BizViewModelName1View : BizView
    {
        /// <summary>デフォルトコンストラクタ</summary>
        public BizViewModelName1View()
        {
            InitializeComponent();
        }

        protected override void BuildBinding()
        {
            var builder = CreateBindingBuilder<BizViewModelName1ViewModel>();

            //ViewModelのプロパティとバインディング
            builder.Element(SampleTextBox1)
                   .Binding(TextBox.TextProperty, x => x.RequiredValue, BindingMode.TwoWay);


            //サンプル エンティティとバインディング
            builder.Element(SampleTextBox2)
                   .Binding(TextBox.TextProperty, x => x.SampleEntity.SampleDate);


            //ViewModelのプロパティとDateConverterを利用してバインディング
            builder.Element(SampleTextBox3)
                   .Binding(TextBox.TextProperty, x => x.SampleDate)
                   .Converter(new DateConverter());

            builder.Element(SampleButton)
                   .Binding(Button.ContentProperty, x => x.SampleButtonName)
                   .Binding(Button.ClickEvent, x => x.SampleAction);
        }
    }

    [ValueConversion(typeof(DateTime), typeof(String))]
    public class DateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            DateTime date = (DateTime)value;
            return date.ToString("yyyy/MM/dd");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string strValue = value as string;
            DateTime resultDateTime;
            if (DateTime.TryParse(strValue, out resultDateTime))
            {
                return resultDateTime;
            }
            return DependencyProperty.UnsetValue;
        }
    }


}
