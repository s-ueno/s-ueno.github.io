﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using uEN.UI;
using uEN.UI.Binding;
using uEN.UI.Validation;

namespace SimpleApp
{
    /// <summary>
    /// 
    /// </summary>
    [VisualElements(typeof(BizViewModelName1View))]
    public class BizViewModelName1ViewModel : BizViewModel, INotifyDataErrorInfo
    {
        public BizViewModelName1ViewModel()
        {
            SampleEntity = new SampleEntity();
        }

        [RequiredRule("必須入力項目です。")]
        public string RequiredValue
        {
            get { return _requiredValue; }
            set
            {
                SetProperty(ref _requiredValue, value);
                OnErrorsChanged("RequiredValue");
            }
        }
        private string _requiredValue = "Hello World !!";

        public SampleEntity SampleEntity { get; set; }

        public DateTime? SampleDate
        {
            get { return _sampleDate; }
            set
            {
                SetProperty(ref _sampleDate, value);
                OnErrorsChanged("SampleDate");
            }
        }
        private DateTime? _sampleDate = DateTime.Now.AddDays(-10);

        public void SampleAction()
        {
            MessageBox.Show("ボタンを押下しました。");
        }
        public string SampleButtonName { get { return "サンプル ボタン"; } }

        #region INotifyDataErrorInfo

        public System.Collections.IEnumerable GetErrors(string propertyName)
        {
            switch (propertyName)
            {
                case "SampleDate":
                    if (SampleDate >= DateTime.Now)
                    {
                        return new[] { "日付は過去日を入力するようにしてください。" };
                    }
                    break;
                default:
                    break;
            }
            return null;
        }

        /// <summary>検証すべきかどうかの判断を行います。</summary>
        public bool HasErrors
        {
            get { return SampleDate.HasValue; }
        }

        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;
        void OnErrorsChanged(string propertyName)
        {
            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        #endregion

    }

    public class SampleEntity : INotifyDataErrorInfo
    {
        [BindingStringFormat("yyyy年MM月dd日")]
        public DateTime? SampleDate
        {
            get { return _sampleDate; }
            set
            {
                _sampleDate = value;
                OnErrorsChanged("SampleDate");
            }
        }
        private DateTime? _sampleDate = DateTime.Now;

        #region INotifyDataErrorInfo

        public System.Collections.IEnumerable GetErrors(string propertyName)
        {
            if (SampleDate < DateTime.Now)
            {
                return new[] { "日付は未来日を入力するようにしてください。" };
            }

            return null;
        }

        /// <summary>検証すべきかどうかの判断を行います。</summary>
        public bool HasErrors
        {
            get { return SampleDate.HasValue; }
        }

        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;
        void OnErrorsChanged(string propertyName)
        {
            if (ErrorsChanged != null) 
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propertyName));
        }

        #endregion

    }

}
