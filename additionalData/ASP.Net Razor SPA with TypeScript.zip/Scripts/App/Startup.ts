﻿// entory point
$safeprojectname$.BizApplication.Resolve();