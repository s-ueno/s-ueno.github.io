﻿namespace $safeprojectname$.Shared {

}