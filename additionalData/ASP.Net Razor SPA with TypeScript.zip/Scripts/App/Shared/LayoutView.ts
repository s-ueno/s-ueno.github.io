﻿namespace $safeprojectname$.Shared {
    export class LayoutView extends DomBehind.BizView {
        BuildBinding(): void {
            let builder = this.CreateBindingBuilder<LayoutViewModel>();

        }

    }
}