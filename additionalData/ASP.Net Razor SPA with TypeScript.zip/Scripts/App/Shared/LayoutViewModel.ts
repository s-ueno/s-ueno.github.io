﻿namespace $safeprojectname$.Shared {
    export class LayoutViewModel extends DomBehind.BizViewModel {
        Initialize(): void {
            
        }

    }
}