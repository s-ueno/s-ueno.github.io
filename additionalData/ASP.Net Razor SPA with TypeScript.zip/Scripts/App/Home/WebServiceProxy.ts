﻿namespace $safeprojectname$.Home {

}