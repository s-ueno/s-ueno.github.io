﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using uEN.UI;
using uEN.Utils;

namespace $rootnamespace$
{
    /// <summary>
    /// 
    /// </summary>
    public partial class $fileinputname$View : BizView
    {
        /// <summary>デフォルトコンストラクタ</summary>
        public $fileinputname$View()
        {
            InitializeComponent();
        }

        protected override void BuildBinding()
        {

        }
    }
}
