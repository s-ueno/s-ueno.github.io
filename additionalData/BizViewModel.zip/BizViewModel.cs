﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uEN.UI;

namespace $rootnamespace$
{
    /// <summary>
    /// 
    /// </summary>
    [VisualElements(typeof($fileinputname$View))]
    public class $fileinputname$ViewModel : BizViewModel
    {
        /// <summary>デフォルトコンストラクタ</summary>
        public $fileinputname$ViewModel()
        {

        }
    }
}
