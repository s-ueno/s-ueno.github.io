﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using uEN.UI;

namespace SimpleApp
{
    /// <summary>
    /// 
    /// </summary>
    [VisualElements(typeof(BizViewModelName1View))]
    public class BizViewModelName1ViewModel : BizViewModel
    {
        public string SampleText { get; set; }
        public void SampleAction()
        {
            MessageBox.Show(SampleText);
        }
        public string SampleButtonName { get { return "サンプル ボタン"; } }
    }
}
