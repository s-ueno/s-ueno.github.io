﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uEN.UI;

namespace SimpleApp
{
    [VisualElements(typeof(MainView))]
    public class MainViewModel : BizViewModel
    {
        public MainViewModel()
        {
            MyProperty = "ViewModelでLob開発";
        }
        public string MyProperty { get; set; }
    }
}
